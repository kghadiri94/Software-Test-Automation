package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.java.model.Task;

class TaskTest {
  @Test
  void testTask() {
    Task task = new Task("0001", "Task name", "Task description");
    assertTrue(task.getTaskId().equalsIgnoreCase("0001"));
    assertTrue(task.getTaskName().equalsIgnoreCase("Task name"));
    assertTrue(task.getTaskDescription().equalsIgnoreCase("Task
description"));
  }

  @Test
  void testTaskIdTooLong() {
    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      new Task("1234567891011", "Task Name", "Task description");
    });
  }

  @Test
  void testTaskIdNull() {
    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      new Task(null, "Task Name", "Task Description");
    });
  }

  @Test
  void testTaskNameTooLong() {
    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      new Task("0001", "Very long task name ", "Task description");
    });
  }

  @Test
  void testTaskNameNull() {
    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      new Task("0001", null, "Task description");
    });
  }

  @Test
  void testTaskDescriptionTooLong() {
    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      new Task("0001", "Task name", "Task description
               ");
    });
  }
  
  @Test
  void testTaskDescriptionNull() {
    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      new Task("0001", "Task name", null);
    });
  }
}
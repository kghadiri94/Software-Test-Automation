package cs320_module3_contact_contactService;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
/*
 *
 * */
      @Test
        void testAdd() {
          ContactService cs = new ContactService();
          
          Contact cs1 = new
Contact("123456789","Chance","OPants","7145559999","123 Fake St Springfield");
          assertEquals(true, cs.addContact(cs1));
        }
  
        @Test
        void testDelete() {
          ContactService cs = new ContactService();
          
          Contact cs1 = new
Contact("123456789","Chance","OPants","7145559999","123 Fake St Springfield");
          Contact cs2 = new Contact("987654321","Kona","Tango","8185556666","456
Kiss St ShelbyVille");
          Contact cs3 = new
Contact("112233445","Ody","Oddysseus","7143337777","789 Sleep St OgdenVille");
          Contact cs4 = new
Contact("335577890","Mite","Dynamite","7148889999","246 Even St Cypress Creek")
            Contact cs5 = new
Contact("224466789","Santa","LHelper","7142226789","135 Odd St Capital City");

          assertEquals(true, cs.deleteContact("987654321"));
          assertEquals(false,cs.deleteContact("657489321"));
          assertEquals(false,cs.deleteContact("224466789"));
        }
  
        @Test
        void testUpdate() {
          ContactService cs = new ContactService();
          
          Contact cs1 = new
Contact("123456789","Chance","OPants","7145559999","123 Fake St Springfield");
          Contact cs2 = new Contact("987654321","Kona","Tango","8185556666","456
Kiss St ShelbyVille");
          Contact cs3 = new
Contact("112233445","Ody","Oddysseus","7143337777","789 Sleep St OgdenVille");
          Contact cs4 = new
Contact("335577890","Mite","Dynamite","7148889999","246 Even St Cypress Creek");
          Contact cs5 = new
Contact("224466789","Santa","LHelper","7142226789","135 Odd St Capital City");

          cs.addContact(cs1);
          cs.addContact(cs2);
          cs.addContact(cs3);
          cs.addContact(cs4);
          cs.addContact(cs5);
          
          assertEquals(true,cs.updateContact("567123456", "Kypto", "SuperDog",
"7144567890", "456 KalEl Krypton"));
          assertEquals(false, cs.updateContact("987321000", "Bat", "Dog",
"7149871111", "890 Wayne Gotham"));
        }
}

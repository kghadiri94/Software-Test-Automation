package cs320_module3_contact_contactService;
import java.util.*;
public class ContactService{
  private ArrayList<Contact> listOfContacts;
  public ContactService() {listOfContacts = new ArrayList<>();
                          }
  public boolean addContact(Contact c) {
    boolean contactExist = false;
    for(Contact l:listOfContacts) {
      if(l.equals(c)) {
        contactExist = true;}
      }
    if(!contactExist) {
      listOfContacts.add(c);
      return true;}
    else {
      return false;}
    }
  public boolean deleteContact(String cid) {
    for(Contact l:listOfContacts) {
      if(l.getContactID().equals(cid)) {
        listOfContacts.remove(l);
        return true;}
      }
      return false;
  }
  
  public boolean updateContact(String cid, String fn, String ln, String
pn, String addr) {
    for(Contact l:listOfContacts) {
      if(l.getContactID().equals(cid)) {
        //checks & update first name
        if(!fn.equals("") && !(fn.length() > 10)) {
          l.setFirstName(fn);
        }
        //checks & update last name
        if(!ln.equals("") && !(ln.length() > 10)) {
          l.setLastName(ln);
            }
        //checks & update phone number
        if(!pn.equals("") && !(pn.length() > 10)) {
          l.setPhoneNumber(pn);
        }
        //checks & update address
        if(!addr.equals("") && !(addr.length() > 30)) {
          l.setAddress(addr);
        }
        return true;
      } //end main if statement
    } //end of loop
    return false;
  } //end of updateContact
} // end class
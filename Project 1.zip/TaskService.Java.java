package cs320_module4_taskService;

import java.util.*;

public class TaskService {
  private final List<Task> listOfTask = new ArrayList<>();
    private String newTaskID() {
      return UUID.randomUUID().toString().substring(
        0, Math.min(toString().length(), 10));
    }
  
  private Task searchForTask(String tid) throws Exception {
    int i = 0;
    while (i < listOfTask.size()) {
      if (tid.equals(listOfTask.get(i).getTaskId())) {
        return listOfTask.get(i);
      }
      i++;
    }
    throw new Exception("task id is not found");
  }
  
  public void addTask(String nm, String desc) {
    Task task = new Task(newTaskID(), nm, desc);
    listOfTask.add(task);
  }
  
  public void deleteTask(String tid) throws Exception {
    listOfTask.remove(searchForTask(tid));
  }

  public void updateName(String tid, String nm) throws Exception {
    searchForTask(tid).setName(nm);
  }

  public void updateDescription(String tid, String desc)
  throws Exception {
    searchForTask(tid).setDescription(desc);
  }
  public List<Task> getlistOfTask() { return listOfTask; }
}
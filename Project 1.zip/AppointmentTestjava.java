package cs320_module5_appointmentservice;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {
  private Date today = new Date();
  private Date futureDate = new Date();
  private Date pastDate = new Date();
  private Date Date(int i, int october, int j) {
    return null;
  }
  
  @Test
  void testGetAppointmentId() {
    futureDate = Date(2025,Calendar.OCTOBER,25);
    pastDate = Date(2021, Calendar.JANUARY,25);
    
    Appointment appt = new
    Appointment("123456789",futureDate,"this is a appointment description");
    assertThrows(IllegalArgumentException.class,
                 () -> appt.getAppointmentID());
    assertThrows(IllegalArgumentException.class,
                 () -> appt.setAppointmentID("12345678900"));
    appt.setAppointmentID("123456789");
    assertEquals("123456789", appt.getAppointmentID());
  }
  
  @Test
  void testSetDate() {
    futureDate = Date(2025,Calendar.OCTOBER,25);
    pastDate = Date(2021, Calendar.JANUARY,25);
    Appointment appt = new Appointment("123456789",pastDate,"this is a appointment description");
    assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate));
    assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate));
    appt.setAppointmentDate(pastDate);
    assertEquals(pastDate, appt.getAppointmentDate());
  }
  
  @Test
  void testGetAppointmentDate() {
    Appointment appt = new Appointment("123456789",futureDate,"this is a appointment description");
    assertNotNull(appt.getAppointmentDate());
    assertEquals(futureDate, appt.getAppointmentDate());
  }
  
  @Test
  void testSetDescription() {
    Appointment appt = new Appointment("123456789",futureDate,"this is a appointment description");
    assertThrows(IllegalArgumentException.class, () -> appt.setDescription("this is a appointment description 2"));
    assertThrows(IllegalArgumentException.class, () -> appt.setDescription("this is a appointment description adding more characters to expand length past 50 chars"));
    appt.setDescription("this is a appointment description");
    assertEquals("this is a appointment description", appt.getDescription());
  }
  
  @Test
  void testGetDescription() {
    Appointment appt = new Appointment("123456789",futureDate,"this is a appointment description");
    assertNotNull(appt.getDescription());
    assertTrue(appt.getDescription().length() <= 50);
    assertEquals("this is a appointment description", appt.getDescription());
  }
}
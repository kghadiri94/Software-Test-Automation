package cs320_module3_contact_contactService;
public class Contact {
  private String contactID; 
  private String firstName; 
  private String lastName; 
  private String phoneNumber; 
  private String address; 
  
  public Contact(String cid, String fn, String ln, String pn, String addr) {
    if(cid == null || cid.length() > 10) {
      throw new IllegalArgumentException("Invalid contact ID - null orlength > 10");
    }
    if(fn == null || fn.length() > 10) {
      throw new IllegalArgumentException("Invalid first name - null orlength > 10");
    }
    if(ln == null || ln.length() > 10) {
      throw new IllegalArgumentException("Invalid last name - null orlength > 10");
    }
    if(pn == null || pn.length() > 10) {
      throw new IllegalArgumentException("Invalid phone number - nullor length > 10");
    }
    if(addr == null || addr.length() > 30) {
      throw new IllegalArgumentException("Invalid address - null orlength > 30");
    }
    
    this.contactID = cid;
    this.firstName = fn;
    this.lastName = ln;
    this.phonenumber = pn;
    this.address = addr;
  }

//start getters
public String getContactID() {
  return this.contactID;
}
public STring getFirstName() {
  return this.firstName;
}
public String getLastName() {
  return this.lastName;
}
public String getPhoneNumber() {
  return this.phoneNumber;
}
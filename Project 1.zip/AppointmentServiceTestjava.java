package aTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

import aService.AppointmentService;

class AppointmentServiceTest {
  private String appointmentID, appointmentDescription, aTooLongDescription;
  private Date appointmentDate, appointmentPastDate;
  
  @SuppressWarnings("deprecation")
  @BeforeEach
  
  void setUp() {
    appointmentID = "1234567890";
    appointmentDescription = "The appt object shall have a required description.";
    appointmentDate = new Date(3021, Calendar.OCTOBER, 12);
    aTooLongDescription = "This description is too long for the appointment requirements but good for testing.";
    appointmentPastDate = new Date(0);
  }

  @Test
  void setAppointment() {
    AppointmentService s = new AppointmentService();
    s.setAppointment();
    assertNotNull(s.getAppointmentList().get(0).getAppointmentId());
    assertNotNull(s.getAppointmentList().get(0).getAppointmentDate());
    assertNotNull(s.getAppointmentList().get(0).getDescription());
    
    s.setAppointment(appointmentDate);
    assertNotNull(s.getAppointmentList().get(1).getAppointmentId());
    assertEquals(appointmentDate,s.getAppointmentList().get(1).getAppointmentDate());
    assertNotNull(s.getAppointmentList().get(1).getDescription());
    s.setAppointment(appointmentDate, appointmentDescription);
    assertNotNull(s.getAppointmentList().get(2).getAppointmentId());
    assertEquals(appointmentDate,s.getAppointmentList().get(2).getAppointmentDate());
    assertEquals(appointmentDescription,s.getAppointmentList().get(2).getDescription());
    assertNotEquals(s.getAppointmentList().get(0).getAppointmentId(),s.getAppointmentList().get(1).getAppointmentId());
    assertNotEquals(s.getAppointmentList().get(0).getAppointmentId(),s.getAppointmentList().get(2).getAppointmentId());
    assertNotEquals(s.getAppointmentList().get(1).getAppointmentId(),s.getAppointmentList().get(2).getAppointmentId());
    assertThrows(IllegalArgumentException.class,() -> s.setAppointment(appointmentPastDate));
    assertThrows(IllegalArgumentException.class,() -> s.setAppointment(appointmentDate, getTooLongDescription()));
  }
  
  @Test
  void deleteAppointment() throws Exception {
    AppointmentService s = new AppointmentService();
    s.setAppointment();
    s.setAppointment();
    s.setAppointment();
    
    String firstId = s.getAppointmentList().get(0).getAppointmentId();
    String secondId = s.getAppointmentList().get(1).getAppointmentId();
    String thirdId = s.getAppointmentList().get(2).getAppointmentId();
    
    assertNotEquals(firstId, secondId);
    assertNotEquals(firstId, thirdId);
    assertNotEquals(secondId, thirdId);
    assertNotEquals(appointmentID, firstId);
    assertNotEquals(appointmentID, secondId);
    assertNotEquals(appointmentID, thirdId);
    assertThrows(Exception.class,() -> s.deleteAppointment(appointmentID));
    s.deleteAppointment(firstId);
    assertThrows(Exception.class,() -> s.deleteAppointment(firstId));
    assertNotEquals(firstId,s.getAppointmentList().get(0).getAppointmentId());
  }
  
  public String getTooLongDescription() {
    return getaTooLongDescription();
  }
  public void setTooLongDescription(String aTooLongDescription) {
    this.setaTooLongDescription(aTooLongDescription);
  }
  public String getaTooLongDescription() {
    return aTooLongDescription;
  }
  public void setaTooLongDescription(String aTooLongDescription) {
    this.aTooLongDescription = aTooLongDescription;
  }
}                
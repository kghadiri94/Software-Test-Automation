package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import main.java.model.Task;
import main.java.model.TaskService;

class TaskServiceTest {
  @Test
  void testAddTask() {
    Task test1 = new Task("00001", "Name", "Description");
    assertEquals(false, TaskService.addTask(test1));
    }
  
  @Test
  void deleteTest() {
    Task test1 = new Task("00001", "Name", "Description");
    TaskService.addTask(test1);
    assertEquals(true, TaskService.deleteTask(test1));
  }
  
  @Test
  void updateTest() {
    Task test1 = new Task("00001", "Name", "Description");
    TaskService.updateTask(test1);
    assertTrue(TaskService.addTask(test1));
  }
}